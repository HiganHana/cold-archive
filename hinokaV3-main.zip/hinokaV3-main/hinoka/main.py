
#fix module lv not at top
import os
import sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from discordSS.simpleBot import bot  # noqa: E402

bot.start()