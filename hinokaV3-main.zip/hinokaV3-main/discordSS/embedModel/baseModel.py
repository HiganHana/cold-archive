
import typing
import parse
from pydantic import BaseModel

def _add_to_collection(func, top, c1 :typing.Iterable, track :set = None):
    if top:
        c1.insert(0, func)
    else:
        c1.append(func)
    
    if track is not None:
        track.add(func)
    
    return func

class EmbedBaseModel(BaseModel):
    
    _format_var_parse_rules : dict
    _pre_field_rules :dict
    _post_field_rules:dict
    _pre_com_rules :list
    _post_com_rules:list
    
    _format_var_single_rule = None
    
    _all_rules = set()
    
    def __init__(self, **data) -> None:
        super().__init__(**data)
        object.__setattr__(self,"_format_var_parse_rules", {})
        object.__setattr__(self, "_format_var_single_rule",None)
        
        object.__setattr__(self,"_pre_field_rules", {})
        object.__setattr__(self,"_post_field_rules", {})
        object.__setattr__(self,"_pre_com_rules", [])
        object.__setattr__(self,"_post_com_rules", [])  
        
        object.__setattr__(self,"_all_rules", set())               
                      
    def setupVarRule(self):
        def decorator(func):
            self._format_var_single_rule = func
                      
    def setup(
        self, name :str = None, 
        top_priority : bool = False, 
        var_rule : bool = False, 
        pre : bool = False
    ):
        """
        decorator of a function
        """
        def decorator(func):
            if func in self._all_rules:
                return func
            
            if name is None and var_rule:
                raise ValueError("var_rule must have a name")
            
            if name is None and pre:
                _add_to_collection(func, top_priority, self._pre_com_rules, self._all_rules)
                return func
            elif name is None:
                _add_to_collection(func, top_priority, self._post_com_rules, self._all_rules)
                return func
            
            if var_rule and pre:
                raise ValueError("var_rule and pre cannot be true at the same time")
            
            if var_rule:
                if name not in self._format_var_parse_rules:
                    self._format_var_parse_rules[name] = []
                _add_to_collection(
                    func, top_priority, self._format_var_parse_rules[name], self._all_rules
                )
                return func
                
            if pre:
                target = self._pre_field_rules
            else:
                target = self._post_field_rules
                
            if name not in target:
                target[name] = []
            _add_to_collection(func, top_priority, target[name], self._all_rules)
            return func
            
        return decorator
    
    def iterFields(self):
        for k in self.__fields__:
            yield k, getattr(self, k)
    
    def _exec_formatVar_rules(self, **kwargs):
        if self._format_var_single_rule is not None:
            kwargs:dict = self._format_var_single_rule(**kwargs)
        
        if len(self._format_var_parse_rules) == 0:
            return kwargs
        
        for k, w in kwargs.items():
            if k not in self._format_var_parse_rules:
                continue
            rules = self._format_var_parse_rules[k]
            for rule in rules:
                w = rule(w)
            kwargs[k] = w  
        
        return kwargs
            
    def _exec_model_rule(self, model, change_var :str =None, *rules : typing.Callable, **kwargs):
        for rule in rules:
            exec_result = rule(model, **kwargs)
            if exec_result is None:
                continue
            if change_var is not None:
                setattr(model,change_var,exec_result)
        
    def format(self, **kwargs):
        kwargs = self._exec_formatVar_rules(**kwargs)
        
        copied = self.copy()
        
        self._exec_model_rule(copied, None, *self._pre_com_rules, **kwargs)
            
        for name, field in copied.iterFields():
            if name in self._pre_field_rules:
                self._exec_model_rule(copied, name, *self._pre_field_rules[name], **kwargs)
                
        for name, field in copied.iterFields():
            if isinstance(field, str) and ("{" in field or "}" in field):
                new_formatted =field.format(**kwargs)
                setattr(copied,name,new_formatted)
                
        for name, field in copied.iterFields():
            if name in self._post_field_rules:
                self._exec_model_rule(copied, name, *self._post_field_rules[name], **kwargs)
                
        self._exec_model_rule(copied, None, *self._post_com_rules, **kwargs)
        
        return copied
    
    @property
    def hasFormatField(self):
        for name, field in self.iterFields():
            if isinstance(field,str) and "{" in field and "}" in field:
                return True
            if isinstance(field, EmbedBaseModel) and field.hasFormatField:
                return True
            
        return False
    
    def toVars(self, model : 'EmbedBaseModel'):
        """
        this function will only work if the embedModel isnt altered with rules
        """
        
        if model is None:
            return None
        
        if not model.hasFormatField:
            return None
        
        # if not same type
        if self.__class__ != model.__class__:
            raise Exception("model is not same type")
        
        vars = {}
        for name, field in self.iterFields():
            if field is None:
                continue
            
            if isinstance(field, list) and len(field) == 0:
                continue
            elif isinstance(field, list) and all(isinstance(x, EmbedBaseModel) for x in field):
                for i,f in enumerate(field):
                    res = f.toVars(getattr(model, name)[i])
                    if res is None:
                        res = {}
                    vars.update(res)
                continue
            
            if isinstance(field, EmbedBaseModel):
                res = field.toVars(getattr(model, name))
                if res is None:
                    res = {}
                vars.update(res)
                continue
            
            if not isinstance(field, str):
                continue
            
            result = parse.parse(getattr(model, name),field )
           
            if result is None:
                continue
            
            vars.update(result.named)

    
        return vars