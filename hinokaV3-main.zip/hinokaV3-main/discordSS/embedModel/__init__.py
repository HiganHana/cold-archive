from discordSS.embedModel.model import FooterModel, AuthorModel, EmbedFieldModel, EmbedModel
