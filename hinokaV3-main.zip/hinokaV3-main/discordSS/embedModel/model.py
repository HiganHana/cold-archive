
from datetime import datetime
import discord
import typing
from discordSS.embedModel.baseModel import EmbedBaseModel

class FooterModel(EmbedBaseModel):
    text : str
    icon_url : str = None
    
    def __init__(self,text :str, icon_url :str=None) -> None:
        super().__init__(text=text, icon_url=icon_url)
    
class AuthorModel(EmbedBaseModel):
    """
    embed author
    """
    name : str = None
    url : str = None
    icon_url : str = None

    def __init__(self, name :str = None, url :str = None, icon_url :str = None) -> None:
        super().__init__(name=name, url=url, icon_url=icon_url)

class EmbedFieldModel(EmbedBaseModel):
    """
    embed field
    """
    name : str
    value : str
    inline : bool = False
    
    def __init__(self, name :str, value :str, inline :bool = False) -> None:
        super().__init__(name=name, value=value, inline=inline)

class EmbedModel(EmbedBaseModel):
    title : str = None
    description : str = None
    url : str = None
    color : int = None
    timestamp : datetime = None
    footer : FooterModel = None
    image : str = None
    thumbnail : str = None
    author : AuthorModel = None
    fields : typing.List[EmbedFieldModel] = None
    CONTEXT_DATA : dict = {}
    
    def __init__(
        self, 
        title :str = None, 
        description :str = None, 
        url :str = None, 
        color :int = None, 
        timestamp :datetime = None, 
        footer :FooterModel = None, 
        image :str = None, 
        thumbnail :str = None, 
        author :AuthorModel = None, 
        fields :typing.List[EmbedFieldModel] = None, 
    ) -> None:
        super().__init__(
            title=title, description=description, 
            url=url, color=color, timestamp=timestamp, 
            footer=footer, image=image, 
            thumbnail=thumbnail, author=author,
            fields=fields
        )
    
    def flatten(self):
        # convert into discord.Embed
        embed = discord.Embed(
            title = self.title,
            description = self.description,
            url = self.url,
            color = self.color,
            timestamp = self.timestamp
        )
        
        if self.footer is not None:
            embed.set_footer(
                text = self.footer.text,
                icon_url = self.footer.icon_url
            )
            
        if self.image is not None:
            embed.set_image(url = self.image)
            
        if self.thumbnail is not None:
            embed.set_thumbnail(url = self.thumbnail)
            
        if self.author is not None:
            embed.set_author(
                name = self.author.name,
                url = self.author.url,
                icon_url = self.author.icon_url
            )
            
        if self.fields is not None:
            for field in self.fields:
                embed.add_field(
                    name = field.name,
                    value = field.value,
                    inline = field.inline
                )
            
        return embed
    
    @classmethod
    def embedToModel(self, embed : discord.Embed):
        # convert discord.Embed into EmbedModel
        model = EmbedModel(
            title = embed.title,
            description = embed.description,
            url = embed.url,
            color = embed.color,
            timestamp = embed.timestamp
        )
        
        if embed.footer is not None:
            model.footer = FooterModel(
                text = embed.footer.text,
                icon_url = embed.footer.icon_url
            )
            
        if embed.image is not None:
            model.image = embed.image.url
            
        if embed.thumbnail is not None:
            model.thumbnail = embed.thumbnail.url
            
        if embed.author is not None:
            model.author = AuthorModel(
                name = embed.author.name,
                url = embed.author.url,
                icon_url = embed.author.icon_url
            )
            
        if embed.fields is not None:
            model.fields = []
            for field in embed.fields:
                model.fields.append(EmbedFieldModel(
                    name = field.name,
                    value = field.value,
                    inline = field.inline
                ))
            
        return model
    
    
    