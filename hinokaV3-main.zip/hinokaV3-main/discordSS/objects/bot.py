from discord.ext import commands
#todo
class BotSS(commands.Bot):
    """

    """
    def load_cog_object(self, cog : commands.Cog):
        """
        loads a cog object
        """
        pass
    
    def load_cog_from_file(self, path : str):
        pass
    
    def load_cog_from_folder(self, path : str):
        pass
        