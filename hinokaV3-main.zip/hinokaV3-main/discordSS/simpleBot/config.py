
import os
import typing
from pydantic import BaseModel
from discordSS.enums import intents_literal

class SimpleBotConfig(BaseModel):
    name : str = None
    packed : bool = True
    
    cog_folder : str = "cogs"
    no_cogs : bool = False
    
    token : str
    
    prefix : str = "!"
    # a list of intent string 
    intents : typing.Union[
        typing.Literal["default","all"], 
        typing.List[intents_literal]
    ] = "all"
    
    @property
    def cog_folder_path(self):
        if self.packed and self.name is None:
            raise ValueError("name must be set if packed is True")
        
        if self.packed:
            return os.path.join(self.name, self.cog_folder)
        
        return self.cog_folder
    