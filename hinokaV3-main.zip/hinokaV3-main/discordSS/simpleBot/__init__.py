from discord import Intents
from discordSS.objects.bot import BotSS
from discordSS.shared import CONFIG
from discordSS.simpleBot.config import SimpleBotConfig
from discordSS.utils.toml import load_toml_file

class simpleBotManager:
    _bot : BotSS
    config : SimpleBotConfig

    @property
    def bot(self):
        return self._bot
    
    def _get_intents(self):
        return Intents.all()
        
        #todo no other intent types available yet
    
    def __init__(self) -> None:
        self.config = SimpleBotConfig(**CONFIG.get("bot",{}))
        
        self._bot = BotSS(
            command_prefix=self.config.prefix,
            intents= self._get_intents()
        )
        
        # load cogs
        if not self.config.no_cogs:
            self.bot.load_cog_from_folder(self.config.cog_folder_path)
        
    def start(self):
        self.bot.run(self.config.token)
    
    def load_persisted_view(self, *args):
        #todo 
        pass
    
bot = simpleBotManager()

__all__ = [
    "bot"
]