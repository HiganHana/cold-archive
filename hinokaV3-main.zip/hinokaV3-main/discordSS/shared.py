
from discordSS.utils.toml import load_toml_file

CONFIG = load_toml_file("bot.toml")