"""
discordSS - Discord.py superset 

provides an extended set of features that allows faster deployment and usage
"""

from discordSS.shared import CONFIG  
