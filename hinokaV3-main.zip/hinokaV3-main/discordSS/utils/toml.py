
import toml
import os

def load_toml_file(
    path, 
    return_empty_if_not_exist :bool=True
):
    if not (exist_flag := os.path.exists(path)) and return_empty_if_not_exist:
        return {}
    elif not exist_flag:
        raise FileNotFoundError(f"file not found: {path}")
        
    with open(path, 'r') as f:
        return toml.load(f)
    
    