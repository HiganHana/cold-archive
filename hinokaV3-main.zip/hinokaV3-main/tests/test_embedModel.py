import unittest

from discordSS.embedModel.model import EmbedModel, AuthorModel, EmbedFieldModel, FooterModel

class Test_EmbedModel(unittest.TestCase):
    def test_embedModel(self):
        example = EmbedModel(
            title="test {name}",
            description="{des1} {des2}",
            footer=FooterModel("hello"),
        )
        
        @example.setup("title", pre=True)
        def title_parse(model, **kwargs):
            return "no more test {name}"
        
        @example.setup(top_priority=True,pre=True)
        def pre_embed_setup(model : EmbedModel, **kwargs):
            self.assertEqual(model.footer.text, "hello")
            model.footer.text = "no hello"

        @example.setup("name",var_rule=True)
        def var_rule_1(w):
            self.assertEqual(w,"hi")
            w = w + "_append"
            return w
        
        embed = example.format(name="hi", des2="kkk", des1="l")
        self.assertEqual(embed.title,"no more test hi_append")
        rembed = embed.flatten()
        
        parsedEmbed = EmbedModel.embedToModel(rembed)
        
        vars = parsedEmbed.toVars(embed)  # noqa: F841
        pass