
import logging

logger = logging.getLogger("hinoka")
