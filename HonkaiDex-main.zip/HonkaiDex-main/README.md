# HonkaiDex

[![Auto Scrapping](https://github.com/HiganHana/HonkaiDex/actions/workflows/scraprunner.yml/badge.svg)](https://github.com/HiganHana/HonkaiDex/actions/workflows/scraprunner.yml)
