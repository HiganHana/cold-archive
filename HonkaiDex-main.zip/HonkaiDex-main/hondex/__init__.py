MIN_LV = 1
MAX_LV = 88
VERSION = 5.7

from hondex.profile import (
    load_battlesuits, 
    load_character, 
    load_stigmata,
    load_all 
)