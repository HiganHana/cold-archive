from honkaiDex.models import HondexModel

class Character(HondexModel):
    name : str
    