
import os
from higanhanaSdk.frame import DcMainframe
from tsukika.models import base

mf = DcMainframe("tsukika")